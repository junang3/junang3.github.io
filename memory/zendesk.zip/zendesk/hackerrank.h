#include <iostream>
#include <cstdio>
#include <string.h>

using namespace std;

//bool is_numeric(const std::string& value) { return std::all_of(value.begin(), value.end(), isdigit); }

int count_c(string s, char d) {
  int count = 0;
  for (int i = 0; i < s.size(); i++)
    if (s[i] == d) count++;
  return count;
}

bool is_numeric(std::string str){
  char c;
  int z;
  int i;  
  z = count_c(str, '.');
    
  if (z>1){
      return false; //not decimal must be a string
  }  
   
  cout << "\n";
  cout << z;
  cout << "\n";
    
  cout << str[1];
    return 0;
}

int main() {
    
    string s;
    getline(cin, s);
    string pch;
    
    char* sc = new char[s.length() + 1];
    strcpy(sc, s.c_str());
// do stuff
//delete [] cstr;
    
    char* chars_array = strtok(sc, " ");
    while(chars_array)
    {
//        MessageBox(NULL, subchar_array, NULL, NULL);
        std::cout << chars_array << '\n';
        chars_array = strtok(NULL, " ");
    }
    
    delete [] sc;

    
    return 0;
}


//conditional -------------------------------------------------------------------

#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <deque>
#include <queue>
#include <stack>
#include <string>
#include <bitset>
#include <cstdio>
#include <limits>
#include <vector>
#include <climits>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <numeric>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <unordered_map>

using namespace std;


int main(){
    int n;
    cin >> n;
    
    string a[] = {"zero","one","two","three","four","five","six","seven","eight","nine"};
    
    
    if (n > 9){
        cout << "Greater than 9";
    } else {
        cout << a[n];
    }
    
    // your code goes here
    return 0;
}

//------------------------------------------- FOR LOOP

#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    // Complete the code.
    int i,j;
    
    cin >> i;
    cin >> j;
    
    string a[] = {"zero","one","two","three","four","five","six","seven","eight","nine"};
    
    for (int x=i;x<=j;x++){
        if (x>9){
            if ( x % 2 == 0 )
            {
                cout << "even";
            } else cout <<"odd";
                
        } else {
            cout << a[x];
        }
        cout << "\n";
    }
    
    return 0;
}


\\ ------------------------------------------- FUNCTIONS

#include <iostream>
#include <cstdio>
using namespace std;

/*
Add `int max_of_four(int a, int b, int c, int d)` here.
*/

int  max_of_four(int a, int b, int c, int d){
    int maxx = 0;
    
    if (maxx<a) maxx=a;
    if (maxx<b) maxx=b;
    if (maxx<c) maxx=c;
    if (maxx<d) maxx=d;
    
    return maxx;
}

int main() {
    int a, b, c, d;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    int ans = max_of_four(a, b, c, d);
    printf("%d", ans);
    
    return 0;
}


\\ ------------------------------------------- POINTER

#include <stdio.h>
#include <cmath>
void update(int *a,int *b) {
    // Complete this function    
    int i = 0;
    i = *a - *b;
    *a = *a + *b;
    *b = std::abs(i);
    
    //printf("%d\n",i);
}

int main() {
    int a, b;
    int *pa = &a, *pb = &b;
    
    scanf("%d %d", &a, &b);
    update(pa, pb);
    printf("%d\n%d", a, b);

    return 0;
}


\\ ------------------------------------------- ARRAY 


#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int n = 0;
    cin >> n;
    int i[n];
    
    int x = 0;
    
    for(x=0;x<n;x++){
        cin >> i[x];
    }
    /*
    cout << i[0] << " ";
    cout << i[1] << " ";
    cout << i[2] << " ";
    cout << i[3] << " ";
    */
    
    
    for(x=n;x>0;x--){
        cout << i[x-1]<<" ";
    }
    
      return 0;
        
}



\\ ------------------------------------------- VARIABLE SIZED ARRAYS

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int n,q;
    int nj; 
    int t,u; //temp int
   
    vector < vector<int> > na;
    scanf("%d %d", &n, &q);
    
    //build array
    for (int i=0;i<n;i++){
        cin >> nj;
        na.push_back(vector<int>()); //empty row
        for (int j=0;j<nj;j++){
            cin >> t;
            na[i].push_back(t);
        }
    }
    //cout << na[0][1]; //test
    for (int i=0;i<q;i++){
        scanf("%d %d", &t, &u);
        cout << na[t][u] << endl;
    }   
   
    return 0;
}
 