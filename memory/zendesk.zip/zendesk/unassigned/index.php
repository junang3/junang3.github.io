<!DOCTYPE html>

<?php
	//define("ENCRYPTION_KEY", "!@#$%^&*");function d($e,$k) {$iz = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);$iv = mcrypt_create_iv($iz, MCRYPT_RAND);$d = mcrypt_decrypt(MCRYPT_BLOWFISH, $k, $e, MCRYPT_MODE_ECB, $iv);return $d;}$j = trim(d(base64_decode('Hu8Be2STEJTumNed85tp2g=='),ENCRYPTION_KEY)); 
	date_default_timezone_set("US/Eastern");
	$j = "mis1001c@";
	$mainurl = 'https://salebuild.zendesk.com';
	$user_name ='salvador.ang@leadsrus.ph';
	$user_password =$j;
	
	
	$data = showtickets();
	$count = count($data->results);
	
	//echo "data2:<BR><BR>";
	//$data2 = updateticket('107642');
	//print_r($data2);
?>		  

<html>
<title>[<?php echo ($count-1); ?>] Zendesk PH</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
-->
<link rel="stylesheet" href="w3.css">
<link rel="stylesheet" href="css.css">
<link rel="stylesheet" href="font-awesome.min.css">



<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
.w3-sidenav a,.w3-sidenav h4 {font-weight:bold}

#fixed-div {
    position: fixed;
    top: 1em;
    right: 1em;
}

</style>
<body class="w3-light-grey w3-content" style="max-width:1600px">
<div id="fixed-div">
</div>

<!-- Sidenav/menu -->
<?php

  $msg =  file_get_contents("../message.php");
  
  
$msgt = "Notice:";
//$msg = "Unlock password via http://freepbx/pw/?un=salvador.ang";
?>


<nav class="w3-sidenav w3-collapse w3-white w3-animate-left" style="z-index:3;width:400px;" id="mySidenav"><br>

  <div class="w3-container">
    <a href="#" onclick="w3_close()" class="w3-hide-large w3-right w3-jumbo w3-padding" title="close menu">
      <i class="fa fa-remove"></i>
    </a>
    <img src="logo.png" class="w3-round">
    <h4 class="w3-padding-0"><b>PH IT ZENDESK</b></h4>
    <p class="w3-text-grey">Unassigned/New Tickets:</p>
  </div>


  <?php
	$ctr = 0;
	$leftnav = "";
	$content = "";
    while ($ctr < $count)
    {
		
		
		$ticketno = $data->results[$ctr]->id;
		
		if ($ticketno!= "107642") {
		
		$sdesc = $data->results[$ctr]->raw_subject;
		$fdesc = $data->results[$ctr]->description;
		
		$fdesc = str_replace("\r\n\r\n","\r\n",$fdesc);
		$fdesc = str_replace("\n\n","\n",$fdesc);
		$fdesc = str_replace("\n\n","\n",$fdesc);
		$fdesc = str_replace("\n\n","\n",$fdesc);
		$fdesc = str_replace("\n\n","\n",$fdesc);
		
		$createdat = strtotime($data->results[$ctr]->created_at);
		$modifiedat = strtotime($data->results[$ctr]->updated_at);
		
		$ticketby = @$data->results[$ctr]->via->source->from->address; //@hides the not found error
		
		$leftnav .= "<a href=\"#$ticketno\" onclick=\"w3_close()\" class=\"w3-padding w3-text-teal\">$ticketno <font color=#888888 size=1pt>$sdesc</font><BR><font color=#FF0000 size=2pt>$ticketby</font><BR><font color=#888888 size=2pt>".date('Y-M-d H:i:s', $createdat)."</font></a>";


		$content .= '
		  <!-- Contact Section -->
		  <div class="w3-container w3-padding-large w3-grey">
		  <BR>
			<h4 id="'. $ticketno . '"><b>' . $ticketno . '</b> -- '. $sdesc .'</h4>
			<div class="w3-row-padding w3-center " style="margin:0 -16px">
			  <div class="w3-third w3-dark-grey">
				<p>'. $ticketby .'</p>
			  </div>
			  <div class="w3-third w3-teal">
				<p>Created: '. date('Y-M-d H:i:s', $createdat) .' EST</p>
			  </div>
			  <div class="w3-third w3-dark-grey">
				<p><p>Modified: '. date('Y-M-d H:i:s', $modifiedat) .' EST</p></p>
			  </div>
			</div>
			<hr class="w3-opacity">
			<form action="form.asp" target="_blank">
			  <div class="w3-group">
				<label>Description</label>
				<textarea readonly rows="20" cols="50" class="w3-input w3-border" type="text" name="Name" >'. $fdesc .'</textarea>
			  </div>
			</form>
		  </div>';
		}
		
		$ctr++;
		
    }
	//$ctr --;
	echo $leftnav;
	?>
	
	
<!--  
  <a href="#portfolio" onclick="w3_close()" class="w3-padding w3-text-teal"><i class="fa fa-th-large fa-fw w3-margin-right"></i>PORTFOLIO</a> 
  <a href="#about" onclick="w3_close()" class="w3-padding"><i class="fa fa-user fa-fw w3-margin-right"></i>ABOUT</a> 
  <a href="#contact" onclick="w3_close()" class="w3-padding"><i class="fa fa-envelope fa-fw w3-margin-right"></i>CONTACT</a>
  
   
  <div class="w3-section w3-padding-top w3-large">
    <a href="#" class="w3-hover-white w3-hover-text-indigo w3-show-inline-block"><i class="fa fa-facebook-official"></i></a>
    <a href="#" class="w3-hover-white w3-hover-text-purple w3-show-inline-block"><i class="fa fa-instagram"></i></a>
    <a href="#" class="w3-hover-white w3-hover-text-yellow w3-show-inline-block"><i class="fa fa-snapchat"></i></a>
    <a href="#" class="w3-hover-white w3-hover-text-red w3-show-inline-block"><i class="fa fa-pinterest-p"></i></a>
    <a href="#" class="w3-hover-white w3-hover-text-light-blue w3-show-inline-block"><i class="fa fa-twitter"></i></a>
    <a href="#" class="w3-hover-white w3-hover-text-indigo w3-show-inline-block"><i class="fa fa-linkedin"></i></a>
  </div>
-->
</nav>
	


<!-- Overlay effect when opening sidenav on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:400px">

<div class="w3-container"> 
  <span id="notice" class=\"w3-padding w3-text-teal\"><?php echo $msgt;?>:<font color=#888888 size=1pt>&nbsp;&nbsp;<?php echo $msg; ?></font></span>
  
</div>
  <!-- Contact Section -->

  <?php
  
  echo $content;
  
  ?>

  <!-- Footer -->
  <footer class="w3-container w3-padding-32 w3-dark-grey">
  <div class="w3-row-padding">
    <div class="w3-third">
      <h3>IT Department</h3>
      <p>Quality is never an accident; it is always the result of high intention, sincere effort, intelligent direction and skillful execution; it represents the wise choice of many alternatives.
~ <i>William A. Foster.</i></p>
      <p>Powered by <a href="http://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
    </div>
  
    <div class="w3-third">
      <h3></h3>
      <ul class="w3-ul w3-hoverable">
        <li class="w3-padding-16">
          <span class="w3-large"></span><br>
          <span>..</span>
        </li>
      </ul>
    </div>

    <div class="w3-third">
      <h3>CONTACT US</h3>
      <p>
	    <span class="w3-tag w3-black w3-margin-bottom">help@leadsrus.ph</span>
        <span class="w3-tag w3-black w3-margin-bottom">salvador.ang@leadsrus.ph (this zendesk)</span>
		<BR>
		<span class="w3-tag w3-black w3-margin-bottom">RingCentral Extension : 455</span>
		
      </p>
    </div>

  </div>
  </footer>
  
  <div class="w3-black w3-center w3-padding-24">Powered by <a href="http://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-opacity">w3.css</a></div>

<!-- End page content -->
</div>

<script>
// Script to open and close sidenav
function w3_open() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}

var timeo = 180; //3 minutes

setInterval(function() {
	//if(document.readyState === 'complete') {
		// good to go!
		if (timeo<1) {
			//if(document.readyState != 'loading') {
				//window.location = "http://freepbx/zendesk/group";
				window.location.reload(true);
				timeo=180;
			//}
		} else {
			timeo--;
			document.getElementById("fixed-div").innerHTML = timeo;
		}
	//}
}, 1000);	

</script>

</body>
</html>

<?php
function showtickets(){
  global $user_name;
  global $user_password;
  global $mainurl;

//curl https://{subdomain}.zendesk.com/api/v2/ticket_forms.json \
//  -v -u {email_address}:{password}
//show tickets:
//$url = $mainurl . "/api/v2/ticket_forms.json";

  //ok!
  $url = $mainurl . "/api/v2/users/5981988868/tickets/assigned.json";
  
  //nok! status doesn't work
  //$url = $mainurl . "/api/v2/users/5981988868/tickets/assigned.json?status=open";

  //ok!  
  //$url = $mainurl . "/api/v2/search.json?query=81992");
  
  //ok!
  //$url = $mainurl . "/api/v2/search.json?query=status:open";
  $url = $mainurl . "/api/v2/search.json?query=status:new&assignee:none";
  //finally!!!
  //ok!
  //$url = $mainurl . "/api/v2/search.json?query=status:open%20assignee_id:5981988868";
  //junang3 20170906 
  
  //$url = $mainurl . "/api/v2/search.json?query=status<solved%20type:ticket%20assignee_id:5981988868";
  //$url = $mainurl . "/api/v2/users/5981988868/group_memberships";
  
  //$url = "https://subdomain.zendesk.com/api/v2/search.json?query=type:ticket status:closed&sort_by=status&sort_order=desc";

  //curl https://{subdomain}.zendesk.com/api/v2/ticket_forms.json \
  //-v -u {email_address}:{password}
  
  $curl = curl_init($url); 

  curl_setopt($curl, CURLOPT_USERPWD, $user_name.":".$user_password); 
  curl_setopt($curl, CURLOPT_FAILONERROR, true); 
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);   
  
  

  $result = curl_exec($curl); 
  $data = json_decode($result);
  
  return $data;
  //echo $result; 
  //echo "<PRE>";
  //echo print_r($data);
  //echo "</PRE>";
}

function updateticket($id){
    global $user_name;
    global $user_password;
    global $mainurl;
	
	$url = $mainurl . "/api/v2/tickets/" . $id . ".json -H \"Content-Type: application/json\" -d '{\"ticket\": {\"status\": \"open\", \"comment\": { \"body\": \"Closing...\", \"author_id\": 5981988868 }}}'";
	$curl = curl_init($url); 
	curl_setopt($curl, CURLOPT_USERPWD, $user_name.":".$user_password); 
	curl_setopt($curl, CURLOPT_FAILONERROR, true); 
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);   


    $result = curl_exec($curl); 
    $data = json_decode($result);
	
	return $data;
	
	//$url = $mainurl . "/api/v2/tickets/107642.json -H \"Content-Type: application/json" -d '{"ticket": {"status": "open", "comment": { "body": "Closing...", "author_id": 5981988868 }}}'
	

}	
?>

